﻿using System;
using System.Threading.Tasks;

namespace SideBar.Components.Services
{
    public class SidebarStateService
    {
        private bool _isSidebarOpen = true;

        public bool IsSidebarOpen
        {
            get => _isSidebarOpen;
            private set
            {
                if (_isSidebarOpen != value)
                {
                    _isSidebarOpen = value;
                    NotifyStateChanged();
                }
            }
        }

        public event Action OnChange;

        public void ToggleSidebar()
        {
            IsSidebarOpen = !IsSidebarOpen;
        }

        public void CloseSidebar()
        {
            IsSidebarOpen = false;
        }

        private void NotifyStateChanged()
        {
            if (OnChange != null)
            {
                OnChange.Invoke();
            }
        }
    }
}
